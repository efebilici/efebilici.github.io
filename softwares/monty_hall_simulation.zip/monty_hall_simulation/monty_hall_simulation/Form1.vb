﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False

        If gamestep = 1 Then
            Button1.BackColor = Color.Yellow
            If windoor = 1 Then
                Dim eleme As Integer
                eleme = random.Next(2, 4)
                If eleme = 2 Then
                    door2()
                ElseIf eleme = 3 Then
                    door3()
                End If
            ElseIf windoor = 2 Then
                door3()
            ElseIf windoor = 3 Then
                door2()
            End If
            writelog("Sunucu tarafından gerçekleştirilen eleme işlemi tamamlandı")
        ElseIf gamestep = 2 Then
            If windoor = 1 Then
                writelog("Tebrikler Kazandınız!")
                win = win + 1
                game = game + 1
            Else
                writelog("Oyunu Kaybettiniz")
                writelog("Arkasında araba olan kapı " & windoor & ". kapıydı")
                lose = lose + 1
                game = game + 1
            End If
            updatestatistics()
        End If
        gamestep = gamestep + 1
        If gamestep > 2 Then
            writelog("______________________________________")
            writelog("Yeni Oyun Başlatıldı")
            start()
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        start()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False

        If gamestep = 1 Then
            Button2.BackColor = Color.Yellow
            If windoor = 2 Then
                Dim eleme As Integer
                eleme = random.Next(2, 4)
                If eleme = 2 Then
                    door1()
                ElseIf eleme = 3 Then
                    door3()
                End If
            ElseIf windoor = 1 Then
                door3()
            ElseIf windoor = 3 Then
                door1()
            End If
            writelog("Sunucu tarafından gerçekleştirilen eleme işlemi tamamlandı")
        ElseIf gamestep = 2 Then
            If windoor = 2 Then
                writelog("Tebrikler Kazandınız!")
                win = win + 1
                game = game + 1
            Else
                writelog("Oyunu Kaybettiniz")
                writelog("Arkasında araba olan kapı " & windoor & ". kapıydı")
                lose = lose + 1
                game = game + 1
            End If
            updatestatistics()
        End If
        gamestep = gamestep + 1
        If gamestep > 2 Then
            writelog("______________________________________")
            writelog("Yeni Oyun Başlatıldı")
            start()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False

        If gamestep = 1 Then
            Button3.BackColor = Color.Yellow
            If windoor = 3 Then
                Dim eleme As Integer
                eleme = random.Next(2, 4)
                If eleme = 2 Then
                    door1()
                ElseIf eleme = 3 Then
                    door2()
                End If
            ElseIf windoor = 2 Then
                door1()
            ElseIf windoor = 1 Then
                door2()
            End If
            writelog("Sunucu tarafından gerçekleştirilen eleme işlemi tamamlandı")
        ElseIf gamestep = 2 Then
            If windoor = 3 Then
                writelog("Tebrikler Kazandınız!")
                win = win + 1
                game = game + 1
            Else
                writelog("Oyunu Kaybettiniz")
                writelog("Arkasında araba olan kapı " & windoor & ". kapıydı")
                lose = lose + 1
                game = game + 1
            End If
            updatestatistics()
        End If
        gamestep = gamestep + 1
        If gamestep > 2 Then
            writelog("______________________________________")
            writelog("Yeni Oyun Başlatıldı")
            start()
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Button4.Enabled = False
        Button5.Enabled = False
        If MaskedTextBox1.Text = "" Then
            MsgBox("Tekrar Adedi Boş Olamaz")
            Button4.Enabled = True
            Button5.Enabled = True
            Exit Sub
        End If
        Dim skapi As Integer
        Dim adet As Integer = MaskedTextBox1.Text
        For i = 1 To adet
            Application.DoEvents()
            skapi = random.Next(1, 4)
            Select Case skapi
                Case 1
                    Button1.PerformClick()
                    Application.DoEvents()
                    Button1.PerformClick()
                    Application.DoEvents()
                Case 2
                    Button2.PerformClick()
                    Application.DoEvents()
                    Button2.PerformClick()
                    Application.DoEvents()
                Case 3
                    Button3.PerformClick()
                    Application.DoEvents()
                    Button3.PerformClick()
                    Application.DoEvents()
            End Select
        Next
        Button4.Enabled = True
        Button5.Enabled = True
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Button4.Enabled = False
        Button5.Enabled = False
        If MaskedTextBox1.Text = "" Then
            MsgBox("Tekrar Adedi Boş Olamaz")
            Button4.Enabled = True
            Button5.Enabled = True
            Exit Sub
        End If
        Dim skapi As Integer
        Dim adet As Integer = MaskedTextBox1.Text
        For i = 1 To adet
            Application.DoEvents()
            skapi = random.Next(1, 4)
            Select Case skapi
                Case 1
                    Button1.PerformClick()
                    Application.DoEvents()
                    If Button2.Enabled = True Then
                        Button2.PerformClick()
                    Else
                        Button3.PerformClick()
                    End If
                    Application.DoEvents()
                Case 2
                    Button2.PerformClick()
                    Application.DoEvents()
                    If Button1.Enabled = True Then
                        Button1.PerformClick()
                    Else
                        Button3.PerformClick()
                    End If
                    Application.DoEvents()
                Case 3
                    Button3.PerformClick()
                    Application.DoEvents()
                    If Button1.Enabled = True Then
                        Button1.PerformClick()
                    Else
                        Button2.PerformClick()
                    End If
                    Application.DoEvents()
            End Select
        Next
        Button4.Enabled = True
        Button5.Enabled = True
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim cevap As MsgBoxResult
        cevap = MsgBox("İstatistikleri sıfırlamak istiyor musunuz?", MsgBoxStyle.YesNo)
        If cevap = MsgBoxResult.Yes Then
            win = 0
            lose = 0
            game = 0
            updatestatistics()
            writelog("İstatistikler sıfırlandı")
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim cevap As MsgBoxResult
        cevap = MsgBox("Log bölümünü temizlemek istiyor musunuz?", MsgBoxStyle.YesNo)
        If cevap = MsgBoxResult.Yes Then
            TextBox1.Text = ""
            writelog("Log Temizlendi")
        End If
    End Sub
End Class
