﻿Module Module1
    Public log As String
    Public win As Integer
    Public lose As Integer
    Public game As Integer
    Public random As New Random
    Public windoor As Integer
    Public gamestep As Integer = 1
    Sub door1()
        Form1.Button1.Enabled = False
        Form1.Button1.BackColor = Color.Red
        Form1.Button2.Enabled = True
        Form1.Button3.Enabled = True
        writelog("Kapı 1 elendi")
        writelog("Kapının Arkasından Eşek Çıktı")
    End Sub
    Sub door2()
        Form1.Button2.Enabled = False
        Form1.Button2.BackColor = Color.Red
        Form1.Button1.Enabled = True
        Form1.Button3.Enabled = True
        writelog("Kapı 2 elendi")
        writelog("Kapının Arkasından Eşek Çıktı")
    End Sub
    Sub door3()
        Form1.Button3.Enabled = False
        Form1.Button3.BackColor = Color.Red
        Form1.Button1.Enabled = True
        Form1.Button2.Enabled = True
        writelog("Kapı 3 elendi")
        writelog("Kapının Arkasından Eşek Çıktı")
    End Sub
    Sub logupdate()
        Form1.TextBox1.AppendText(log)
    End Sub
    Sub writelog(plog)
        log = plog & vbCrLf
        logupdate()
    End Sub
    Sub start()
        windoor = random.Next(1, 4)
        writelog("Kazanan kapı belirlendi")
        gamestep = 1
        Form1.Button1.Enabled = True
        Form1.Button2.Enabled = True
        Form1.Button3.Enabled = True
        Form1.Button1.BackColor = Color.FromKnownColor(KnownColor.Control)
        Form1.Button2.BackColor = Color.FromKnownColor(KnownColor.Control)
        Form1.Button3.BackColor = Color.FromKnownColor(KnownColor.Control)
    End Sub
    Sub updatestatistics()

        Form1.TextBox2.Text = win & " %" & (win * 100) / game
        Form1.TextBox3.Text = lose & " %" & (lose * 100) / game
        Form1.TextBox4.Text = game
    End Sub
End Module
